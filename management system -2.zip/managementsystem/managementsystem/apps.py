from django.apps import AppConfig


class ManagementsystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'managementsystem'
